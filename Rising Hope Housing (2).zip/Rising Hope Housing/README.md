# My Website Project

This is a simple website project built using HTML, Css and JavaScript.

##  Project Structure
-home.html-Home page
-about.tml-About Us page
-news.html-News page 
-products.html-products page
-css/-Stylesheets
-readme.md-Project documentation

## Project Features

-Responsive navigation bar
-css styling in modular ways

## Technologies Used
 -For structure used **HTML(part 1)
 -for styling and responsive used **CSS(part 2)
-Lastly JavaScript will be used for inactivitying(part 3)

## How to Run it 
  -open the folder,double click on any webpage(e.g. home.html) and the it will open in your browser

## future improvements
-Improve accessibility
-making the contact form valid


## Author
Lesego Leqola-{st10473205@rrcconnect.edu.za}